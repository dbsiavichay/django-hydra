""" Sites for menus """

# Models
from .models import Menu

# Model Site
from hydra import ModelSite


class AccountSite(ModelSite):
    """Site for menu model"""

    model = Menu
    list_display = ('__str__', 'content_type', 'icon_class', 'sequence')
