#Python
import inspect
from importlib import import_module

# Django
from django.urls import path
from django.utils.text import slugify

# Views
from .views import ModuleView

def get_module_urls():
    urlspatterns = []
    try:
        module = import_module("hydra.models")
        members = inspect.getmembers(module)
        Model = None
        for name, cls in members:
            if name == "Menu":
                Model = cls
                break
    except ModuleNotFoundError as error:
        print("Not found hydra.models")

    if Model is None:
        print("Not found Menu model")
        return
    
    menus = Model.objects.filter(content_type__isnull=True)
    
    for menu in menus:
        urlspatterns.append(
            path(
                route = "%s/" % menu.route,
                view = ModuleView.as_view(),
                name = slugify(menu.name)
            )
        ) 
    return urlspatterns

